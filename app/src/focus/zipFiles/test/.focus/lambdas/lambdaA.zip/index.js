module.exports = () => 2
